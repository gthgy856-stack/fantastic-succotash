package com.duel.gui;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.utils.ItemUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class GameSelectorGUI implements InventoryHolder {

    public static final String TITLE = "§8⚔ §bDuel Arena §8— §7Choose your game";

    private final DuelPlugin plugin;
    private final Inventory inventory;

    // slot → Arena (so click handler doesn't rely on index order)
    private final Map<Integer, Arena> slotArenaMap = new HashMap<>();

    public GameSelectorGUI(DuelPlugin plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 54, Component.text("⚔ Duel Arena — Choose your game")
                .color(NamedTextColor.DARK_AQUA)
                .decoration(TextDecoration.BOLD, false));
        populate();
    }

    private void populate() {
        // Fill border with dark glass
        ItemStack border = ItemUtils.buildFiller(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 9; i++)  inventory.setItem(i, border);
        for (int i = 45; i < 54; i++) inventory.setItem(i, border);
        for (int i = 9; i < 45; i += 9)  inventory.setItem(i, border);
        for (int i = 17; i < 45; i += 9) inventory.setItem(i, border);

        Collection<Arena> arenas = plugin.getArenaManager().getAllArenas();
        int[] slots = getInteriorSlots();
        int slotIdx = 0;

        for (Arena arena : arenas) {
            if (slotIdx >= slots.length) break;
            int guiSlot = slots[slotIdx++];

            // Use first GUI item if available, otherwise fallback to DIAMOND_SWORD
            ItemStack display;
            List<ItemStack> items = arena.getGuiItems();
            if (items != null && !items.isEmpty()) {
                display = items.get(0).clone();
            } else {
                display = new ItemStack(Material.DIAMOND_SWORD);
            }

            ItemMeta meta = display.getItemMeta();
            if (meta == null) meta = Bukkit.getItemFactory().getItemMeta(display.getType());

            // Title = arena name
            meta.displayName(Component.text("⚔ " + arena.getId())
                    .color(NamedTextColor.AQUA)
                    .decoration(TextDecoration.BOLD, true)
                    .decoration(TextDecoration.ITALIC, false));

            int playing = plugin.getDuelManager().getActiveCountForArena(arena.getId());
            int waiting = plugin.getQueueManager().getQueueSize(arena);

            List<Component> lore = new ArrayList<>();
            lore.add(Component.text("Playing: ").color(NamedTextColor.GRAY)
                    .append(Component.text(String.valueOf(playing)).color(NamedTextColor.GREEN))
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Waiting: ").color(NamedTextColor.GRAY)
                    .append(Component.text(String.valueOf(waiting)).color(NamedTextColor.YELLOW))
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.empty());
            lore.add(Component.text("▶ Click to queue").color(NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);

            display.setItemMeta(meta);
            inventory.setItem(guiSlot, display);
            slotArenaMap.put(guiSlot, arena);
        }

        // If no arenas yet, show placeholder
        if (arenas.isEmpty()) {
            ItemStack ph = ItemUtils.build(Material.BARRIER, "No Arenas Configured",
                    NamedTextColor.RED, "Use /GUI create to add arenas");
            inventory.setItem(22, ph);
        }
    }

    /** Returns the Arena mapped to this GUI slot, or null if none. */
    public Arena getArenaAt(int slot) {
        return slotArenaMap.get(slot);
    }

    public static int[] getInteriorSlots() {
        // Rows 2-5, cols 2-8 = slots 10-16, 19-25, 28-34, 37-43
        List<Integer> slots = new ArrayList<>();
        for (int row = 1; row <= 4; row++) {
            for (int col = 1; col <= 7; col++) {
                slots.add(row * 9 + col);
            }
        }
        return slots.stream().mapToInt(Integer::intValue).toArray();
    }

    public static void open(DuelPlugin plugin, Player player) {
        GameSelectorGUI gui = new GameSelectorGUI(plugin);
        player.openInventory(gui.getInventory());
    }

    @Override
    public Inventory getInventory() { return inventory; }
}
